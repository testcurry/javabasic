CREATE PROCEDURE mypro_stu()
  BEGIN
SELECT sname FROM student;
END;

