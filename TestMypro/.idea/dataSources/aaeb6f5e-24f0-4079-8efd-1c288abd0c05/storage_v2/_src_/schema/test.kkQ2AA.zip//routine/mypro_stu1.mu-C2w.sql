CREATE PROCEDURE mypro_stu1()
  BEGIN
UPDATE student SET sname='刺青' WHERE sid=1001;
SELECT sname FROM student;
END;

