CREATE PROCEDURE mypro_msg()
  BEGIN
SELECT 'hello' AS msg;
END;

