CREATE PROCEDURE mypro_if(IN sex INT)
  BEGIN
IF sex=1 THEN
SELECT '男' AS '性别';
ELSEIF sex=2 THEN
SELECT '女' AS '性别';
ELSE 
SELECT '未知' AS '性别';
END IF;
END;

