CREATE PROCEDURE mypro_abs(IN x INT, OUT abs_x INT)
  BEGIN
SET abs_x=ABS(X);
END;

