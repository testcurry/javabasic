CREATE PROCEDURE mypro_math(IN x INT, IN y INT, OUT result INT)
  BEGIN
IF x>y THEN
SET result = x-y;
ELSE 
SET result = x+y;
END IF;
END;

