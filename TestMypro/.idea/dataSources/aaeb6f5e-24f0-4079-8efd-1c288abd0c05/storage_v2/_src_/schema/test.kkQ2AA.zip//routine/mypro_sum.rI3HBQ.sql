CREATE PROCEDURE mypro_sum(IN x INT, OUT total INT)
  BEGIN
DECLARE i INT DEFAULT 0;
SET total=0;
WHILE i<=x
DO
SET total=total + i;
SET i=i+1;
END WHILE;
END;

